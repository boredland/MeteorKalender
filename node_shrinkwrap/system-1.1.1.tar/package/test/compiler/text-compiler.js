module.exports = function compile(module) {
    module.exports = module.text;
};
