/*eslint no-console: [0]*/
/*global console*/
exports.assert = function () {};
exports.print = console.log.bind(console);
