/*eslint no-unused-vars: [0]*/
var a = require("./a");
var test = require("test");
test.assert(exports.monkey === 10, "monkeys permitted");
