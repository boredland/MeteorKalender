/*eslint no-unused-vars:[0]*/
var hasOwnProperty = require("./hasOwnProperty");
var toString = require("./toString");
