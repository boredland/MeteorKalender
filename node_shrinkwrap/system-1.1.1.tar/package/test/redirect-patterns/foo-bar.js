module.exports = "Hello, Foo!";
