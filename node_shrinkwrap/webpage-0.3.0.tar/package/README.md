# webpage
Webpage Boilerplate Component

```js
var webpage = require('webpage');
var body    = webpage({
  // OPTIONAL
  // ... and more in the future (e.g. icon, og, ...)
  title       : 'Foobar',
  description : 'foo bar baz',
  keywords    : 'foo, bar, baz',
  author      : 'quux baz',
  website     : 'http://foo.bar.baz'
});
