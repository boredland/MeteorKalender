0.9.3 - 2015-02-10
  - support `mrt shell`, thanks @gsuess

0.7.3 - 2014-04-04
  - die loudly if there's a problem with the meteor process. Thanks @mitar

0.7.1 - 2014-01-02
  - fixed issue with smart.lock being written incorrectly

0.7.0 - 2013-12-20
  - fixed acceptance tests to work with latest meteor
  - use single package publication for package installs, should be much quicker
  - added a package search tool
  - log package installs to atmosphere

0.6.16 - 2013-11-3
  - smarter searching for package.js, thanks @childdude
  - added `mrt remove`

0.6.15 - 2013-10-20
  - don't write to .meteor/packages, thanks @mitar

0.6.14 - 2013-10-2
  - added --build-dev-bundle option

0.6.13 - 2013-09-13
  - deal with gitignore issue, thanks @philcockfield

0.6.12 - 2013-09-4
  - deal with .build directorys, thanks @mitar

0.6.11 - 2013-08-16
  - minor fix to postinstall script, thanks @veell

0.6.10 - 2013-08-10
  - fixed problem with homedir containing spaces.

0.6.9 - 2013-08-2
  - added `link-package` command

0.6.8 - 2013-07-22
  - added `create-package` command
  - updated prompt dependency

0.6.7 - 2013-07-4
  - switched back to port 443

0.6.4 - 2013-06-17
  - added --verbose argument.

0.6.3 - 2013-06-13
  - Default to port 80

0.6.2 - 2013-06-13
  - Commented out completion postinstall stuff.

0.6.1 - 2013-06-11
  - Error message if default meteor isn't installed and we try to use it.

0.6.0 - 2013-06-07
  - use Meteor's `packages/` directory

0.5.0 - 2013-03-18
  - upgrade to ddp version pre1 package.

0.4.8
  - fixed problem with local sources that form a dep diamond (#93)
